const mafab = require('./mafabAdapter')

function selectedAdapters(config) {
  const adapters = []
  if (config?.sources?.mafab) adapters.push(mafab)
  return adapters
}

function adaptersForCatalog(config, catalogId) {
  if (String(catalogId || '').startsWith('mafab-')) return config?.sources?.mafab ? [mafab] : []
  return []
}

function dedupeMetas(metas) {
  const map = new Map()
  for (const m of metas) {
    if (!m || !m.id) continue
    if (!map.has(m.id)) {
      map.set(m.id, m)
      continue
    }
    const prev = map.get(m.id)
    map.set(m.id, {
      ...prev,
      poster: prev.poster || m.poster,
      description: prev.description || m.description,
      imdb_id: prev.imdb_id || m.imdb_id,
      website: prev.website || m.website,
      releaseInfo: prev.releaseInfo || m.releaseInfo
    })
  }
  return [...map.values()]
}

async function fetchCatalogFromSources(config, { type, catalogId, genre, skip, limit }) {
  const adapters = adaptersForCatalog(config, catalogId)
  if (!adapters.length) return { metas: [] }

  const settled = await Promise.allSettled(adapters.map((a) => a.fetchCatalog({ type, catalogId, genre, skip: 0, limit: 250 })))
  const metas = []
  const warnings = []

  settled.forEach((item, i) => {
    const adapter = adapters[i]
    if (item.status === 'fulfilled') {
      metas.push(...(item.value.metas || []))
      if (item.value.warnings?.length) warnings.push(...item.value.warnings)
    } else {
      warnings.push(`${adapter.SOURCE_NAME}: ${item.reason?.message || 'failed'}`)
    }
  })

  const merged = dedupeMetas(metas).slice(skip, skip + limit)
  return { metas: merged, warnings }
}

async function fetchMetaFromSources(config, { id }) {
  const adapters = selectedAdapters(config)
  for (const a of adapters) {
    try {
      const out = await a.fetchMeta({ id })
      if (out?.meta) return { meta: out.meta }
    } catch {
      // no-op
    }
  }
  return { meta: null }
}

async function fetchStreamsFromSources(config, { type, id }) {
  if (config?.features?.externalLinks === false) return { streams: [] }
  const adapters = selectedAdapters(config)
  for (const a of adapters) {
    try {
      const out = await a.fetchStreams({ type, id, config })
      if (out?.streams?.length) return out
    } catch {
      // no-op
    }
  }
  return { streams: [] }
}

module.exports = {
  fetchCatalogFromSources,
  fetchMetaFromSources,
  fetchStreamsFromSources
}
